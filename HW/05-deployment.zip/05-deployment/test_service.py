import requests

# URL вашого FastAPI сервісу
# Якщо ви запускаєте його локально, це буде http://localhost:8000
url = "http://localhost:8000/predict"

# Дані клієнта для оцінки, як зазначено в завданні
client = {
    "lead_source": "organic_search",
    "number_of_courses_viewed": 4,
    "annual_income": 80304.0
}

# Надсилаємо POST-запит до сервісу
response = requests.post(url, json=client).json()

# Виводимо отриману ймовірність
print(f"Ймовірність конверсії для цього клієнта: {response['conversion_probability']:.3f}")
