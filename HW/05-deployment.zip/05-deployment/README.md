## Домашнє завдання

> Примітка: іноді ваша відповідь не збігається з одним із варіантів точно.
> Це нормально.
> Виберіть варіант, який є найближчим до вашого рішення.

Ми рекомендуємо використовувати python 3.12 або 3.13 у цьому домашньому завданні.

У цьому домашньому завданні ми продовжимо працювати з набором даних для оцінки потенційних клієнтів (lead scoring). Вам не потрібен набір даних: ми надамо модель.


## Запитання 1

* Встановіть `uv`
* Яка версія `uv` була встановлена?
* Використайте `--version`, щоб дізнатися


## Ініціалізуйте порожній проект uv

Вам слід створити порожню папку для домашнього завдання
і зробити це там.


## Запитання 2

* Використайте `uv` для встановлення Scikit-Learn версії 1.6.1
* Який перший хеш для Scikit-Learn ви отримали у файлі блокування (lock file)?
* Включіть весь рядок, що починається з `sha256:`, не включайте лапки


## Моделі

Ми підготували конвеєр (pipeline) з `DictVectorizer` та моделлю.

Він був навчений (приблизно) за допомогою цього коду:

```python
categorical = ['lead_source']
numeric = ['number_of_courses_viewed', 'annual_income']

df[categorical] = df[categorical].fillna('NA')
df[numeric] = df[numeric].fillna(0)

train_dict = df[categorical + numeric].to_dict(orient='records')

pipeline = make_pipeline(
    DictVectorizer(),
    LogisticRegression(solver='liblinear')
)

pipeline.fit(train_dict, y_train)
```

> **Примітка**: Вам не потрібно навчати модель. Цей код лише для довідки.

А потім збережений за допомогою Pickle. Завантажте його тут.

За допомогою `wget`:

```bash
wget https://github.com/DataTalksClub/machine-learning-zoomcamp/raw/refs/heads/master/cohorts/2025/05-deployment/pipeline_v1.bin
```


## Запитання 3

Використаємо модель!

* Напишіть скрипт для завантаження конвеєра за допомогою pickle
* Оцініть цей запис:

```json
{
    "lead_source": "paid_ads",
    "number_of_courses_viewed": 2,
    "annual_income": 79276.0
}
```

Яка ймовірність того, що цей потенційний клієнт конвертується?

* 0.333
* 0.533
* 0.733
* 0.933

Якщо ви отримуєте помилки при розпакуванні файлів, перевірте їх контрольну суму:

```bash
$ md5sum pipeline_v1.bin
7d17d2e4dfbaf1e408e1a62e6e880d49 *pipeline_v1.bin
```


## Запитання 4

Тепер надамо цю модель як веб-сервіс

* Встановіть FastAPI
* Напишіть код FastAPI для обслуговування моделі
* Тепер оцініть цього клієнта за допомогою `requests`:

```python
url = "YOUR_URL"
client = {
    "lead_source": "organic_search",
    "number_of_courses_viewed": 4,
    "annual_income": 80304.0
}
requests.post(url, json=client).json()
```

Яка ймовірність того, що цей клієнт отримає підписку?

* 0.334
* 0.534
* 0.734
* 0.934


## Docker

Встановіть Docker.
Ми будемо використовувати його для наступних двох запитань.

Для цих запитань ми підготували базовий образ: `agrigorev/zoomcamp-model:2025`.
Вам потрібно буде його використовувати (див. Запитання 5 для прикладу).

Цей образ базується на `3.13.5-slim-bookworm` і містить
конвеєр з логістичною регресією (іншою)
а також `dictionary vectorizer` всередині.

Ось як виглядає Dockerfile для цього образу:

```docker
FROM python:3.13.5-slim-bookworm
WORKDIR /code
COPY pipeline_v2.bin .
```

Ми вже зібрали його, а потім завантажили до `agrigorev/zoomcamp-model:2025`.

> **Примітка**: Вам не потрібно збирати цей образ Docker, це лише для довідки.


## Запитання 5

Завантажте базовий образ `agrigorev/zoomcamp-model:2025`. Ви можете легко зробити це за допомогою команди docker pull.

Отже, який розмір цього базового образу?

* 45 МБ
* 121 МБ
* 245 МБ
* 330 МБ

Ви можете отримати цю інформацію, запустивши `docker images` – вона буде в стовпці "SIZE".


## Dockerfile

Тепер створіть свій власний `Dockerfile` на основі підготовленого нами образу.

Він повинен починатися так:

```docker
FROM agrigorev/zoomcamp-model:2025
# додайте свій вміст тут
```

Тепер доповніть його:

* Встановіть усі залежності з `pyproject.toml`
* Скопіюйте свій скрипт FastAPI
* Запустіть його за допомогою `uvicorn`

Після цього ви можете зібрати свій образ Docker.


## Запитання 6

Запустимо ваш контейнер Docker!

Після запуску оцініть цього клієнта ще раз:

```python
url = "YOUR_URL"
client = {
    "lead_source": "organic_search",
    "number_of_courses_viewed": 4,
    "annual_income": 80304.0
}
requests.post(url, json=client).json()
```

Яка ймовірність того, що цей потенційний клієнт конвертується?

* 0.39
* 0.59
* 0.79
* 0.99


## Надіслати результати

* Надішліть свої результати тут: https://courses.datatalks.club/ml-zoomcamp-2025/homework/hw05
* Якщо ваша відповідь не збігається з варіантами точно, виберіть найближчий



## Публікація на Docker Hub

Це лише для довідки, ось як ми публікували образ на Docker Hub.

`Dockerfile_base`:

```dockerfile
FROM python:3.13.5-slim-bookworm
WORKDIR /code
COPY pipeline_v2.bin .
```

Публікація:

```bash
docker build -t mlzoomcamp2025_hw5 -f Dockerfile_base .
docker tag mlzoomcamp2025_hw5:latest agrigorev/zoomcamp-model:2025
docker push agrigorev/zoomcamp-model:2025
```