import pickle
from fastapi import FastAPI
from pydantic import BaseModel

# Завантажуємо модель при старті додатку
# Переконайтеся, що pipeline_v1.bin знаходиться в тій самій директорії
try:
    with open('pipeline_v2.bin', 'rb') as f_in:
        pipeline = pickle.load(f_in)
except FileNotFoundError:
    print("Помилка: Файл 'pipeline_v1.bin' не знайдено.")
    print("Будь ласка, переконайтеся, що він знаходиться в тій самій папці, що і app.py.")
    exit()

app = FastAPI()

# Визначаємо Pydantic модель для вхідних даних
# Це допомагає FastAPI автоматично валідувати вхідні JSON-дані
class Lead(BaseModel):
    lead_source: str
    number_of_courses_viewed: int
    annual_income: float

# Визначаємо кореневий ендпоінт для перевірки, що сервіс працює
@app.get("/")
def read_root():
    return {"message": "Модель оцінки потенційних клієнтів готова!"}

# Визначаємо ендпоінт для прогнозування
@app.post("/predict")
def predict(lead: Lead):
    # Перетворюємо Pydantic модель на словник
    client_record = lead.dict()

    # Робимо прогноз за допомогою завантаженого конвеєра
    # predict_proba повертає ймовірності для кожного класу [негативний, позитивний]
    # Ми беремо ймовірність позитивного класу (індекс 1)
    prediction_probabilities = pipeline.predict_proba([client_record])[0]
    conversion_probability = prediction_probabilities[1]

    return {
        "conversion_probability": float(conversion_probability)
    }

